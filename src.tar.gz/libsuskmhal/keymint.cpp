#ifndef SUSKEYMASTER_HAL_DISABLE_KEYMINT

#ifndef SUSKEYMASTER_BUILD_HOST
#include "suskmhal.hpp"
#include "keymaster-types-c.h"
#include "keymaster-types-cpp.hpp"
#include "transport/hal.h"
#include "transport/keymint-types-aidl.h"
#include <cstdlib>

namespace suskeymaster {
namespace kmhal {

using namespace generic;
using transport::init_parse_p, transport::init_write_p,
      transport::init_parse_i, transport::init_write_i;

SusAidlKeyMint::SusAidlKeyMint() :
    hal_(kmhal_aidl_sp_new_get(
                "android.hardware.security.keymint.IKeyMintDevice", "strongbox",
                nullptr, false), &transport::kmhal_sp_deleter)
{
    if (this->hal_.get() == nullptr) {
        std::cerr << "Failed to initialize KeyMint AIDL HAL" << std::endl;
        return;
    }

    if (kmhal_get_aidl_interface_version(this->hal_.get(), &this->keymint_version) != OK) {
        std::cerr << "Failed to get KeyMint interface version" << std::endl;
        this->keymint_version = -1;
        this->hal_.reset();
        return;
    }
}

static void convertAndDestroyKeyCharacteristics(KeyCharacteristics& out,
                                struct aidl_vec_of_key_characteristics &res_kc_vec);

#define check_hal_ok() do {                                         \
    if (!this->isHALOk()) {                                         \
        std::cerr << __func__ << ": HAL is not OK!" << std::endl;   \
        return ErrorCode::SECURE_HW_COMMUNICATION_FAILED;           \
    }                                                               \
} while (0)

using /*transport::init_write, */transport::init_parse_i;

struct kmhal_sp * SusAidlKeyMint::getHalSp() const
{
    return this->hal_.get();
}

bool SusAidlKeyMint::isHALOk(void) const
{
    return this->hal_.get() != nullptr &&
        this->keymint_version > 0 &&
        kmhal_ping(this->hal_.get()) == OK;
}

u32 SusAidlKeyMint::getVersion(void) const
{
    return this->keymint_version > 0 ? this->keymint_version * 0x100 : -1;
}

void SusAidlKeyMint::getHardwareInfo(SecurityLevel& out_securityLevel,
            std::string& out_keymasterName, std::string& out_keymasterAuthorName)
{
    if (!this->isHALOk()) {
fail:
        out_securityLevel = SecurityLevel::SOFTWARE;
        out_keymasterName = "N/A";
        out_keymasterAuthorName = "N/A";
        return;
    }

    struct kmhal_arg_write_desc *const in_args = nullptr;
    const size_t n_in_args = 0;

    struct aidl_keymint_hardware_info hwinfo = {};

    struct kmhal_arg_parse_desc out_args[] = {
        init_parse_i("KeyMintHardwareInfo", &hwinfo, parse_aidl_keymint_hardware_info)
    };
    const size_t n_out_args = u_arr_size(out_args);

    if (kmhal_call(this->hal_.get(), 1,
            in_args, n_in_args, out_args, n_out_args) != OK)
    {
        std::cerr << "getHardwareInfo call failed!" << std::endl;
        goto fail;
    }

    out_keymasterName = std::string((const char *)hwinfo.keyMintName);
    out_keymasterAuthorName = std::string((const char *)hwinfo.keyMintAuthorName);
    out_securityLevel = static_cast<SecurityLevel>(hwinfo.securityLevel);

    destroy_aidl_keymint_hardware_info(&hwinfo);
}

ErrorCode SusAidlKeyMint::addRngEntropy(std::vector<u8> const& data)
{
    const struct aidl_vec_of_u8 aidl_data = toAidlView(data);

    struct kmhal_arg_write_desc in_args[] = {
        init_write_i("data", &aidl_data, write_aidl_vec_of_u8)
    };
    const size_t n_in_args = u_arr_size(in_args);

    struct kmhal_arg_parse_desc *const out_args = nullptr;
    const size_t n_out_args = 0;

    if (kmhal_call(this->hal_.get(), 2,
                in_args, n_in_args, out_args, n_out_args))
    {
        std::cerr << __func__ << ": AIDL call failed" << std::endl;
        return ErrorCode::SECURE_HW_COMMUNICATION_FAILED;
    }

    return ErrorCode::OK;
}

ErrorCode SusAidlKeyMint::generateKey(std::vector<KeyParameter> const& keyParams,
        std::vector<u8>& out_keyBlob, KeyCharacteristics& out_keyCharacteristics)
{
    struct aidl_vec_of_key_parameter aidl_keyParams = toAidlView(keyParams);

    u32 dummy = 0;
    struct kmhal_arg_write_desc in_args[] = {
        init_write_i("keyParams", &aidl_keyParams, write_aidl_vec_of_key_parameter),
        init_write_p("attestationKey", dummy, kmhal_arg_write_u32),
    };
    const size_t n_in_args = u_arr_size(in_args);

    struct aidl_key_creation_result res{};
    struct kmhal_arg_parse_desc out_args[] = {
        init_parse_i("KeyCreationResult", &res, parse_aidl_key_creation_result)
    };
    const size_t n_out_args = u_arr_size(out_args);

    if (kmhal_call(this->hal_.get(), 3,
                in_args, n_in_args, out_args, n_out_args))
    {
        std::cerr << __func__ << ": AIDL call failed" << std::endl;
        destroy_aidl_vec_of_key_parameter(&aidl_keyParams);
        destroy_aidl_key_creation_result(&res);
        return ErrorCode::SECURE_HW_COMMUNICATION_FAILED;
    }

    /* Copy the keyblob */
    out_keyBlob = fromAidl(res.key_blob);

    /* Convert the KeyCharacteristics */
    convertAndDestroyKeyCharacteristics(out_keyCharacteristics, res.key_characteristics);

    destroy_aidl_vec_of_key_parameter(&aidl_keyParams);
    destroy_aidl_key_creation_result(&res);

    return ErrorCode::OK;
}

ErrorCode SusAidlKeyMint::importKey(std::vector<KeyParameter> const& keyParams,
        KeyFormat keyFormat, std::vector<u8> const& keyData,
        std::vector<u8>& out_keyBlob, KeyCharacteristics& out_keyCharacteristics)
{
    (void) keyParams; (void) keyFormat; (void) keyData;
    (void) out_keyBlob; (void) out_keyCharacteristics;
    return ErrorCode::UNIMPLEMENTED;
}

ErrorCode SusAidlKeyMint::importWrappedKey(std::vector<u8> const& wrappedKeyData,
        std::vector<u8> const& wrappingKeyBlob, std::vector<u8> const& maskingKey,
        std::vector<KeyParameter> const& unwrappingParams,
        uint64_t passwordSid, uint64_t biometricSid,
        std::vector<u8>& out_keyBlob, KeyCharacteristics& out_keyCharacteristics)
{
    (void) wrappedKeyData; (void) wrappingKeyBlob; (void) maskingKey; (void) unwrappingParams;
    (void) passwordSid; (void) biometricSid; (void) out_keyBlob; (void) out_keyCharacteristics;
    return ErrorCode::UNIMPLEMENTED;
}

ErrorCode SusAidlKeyMint::getKeyCharacteristics(std::vector<u8> const& keyBlob,
        std::vector<u8> const& applicationId, std::vector<u8> const& applicationData,
        KeyCharacteristics& out_keyCharacteristics)
{
    /*
    KeyCharacteristics[] getKeyCharacteristics(
            in byte[] keyBlob, in byte[] appId, in byte[] appData);
            */
    /* None of these have to be destroyed
     * since `toAidlView` just assigns the std::vector's pointer,
     * doesn't allocate anything */
    const struct aidl_vec_of_u8 aidl_keyBlob = toAidlView(keyBlob);
    const struct aidl_vec_of_u8 aidl_appId = toAidlView(applicationId);
    const struct aidl_vec_of_u8 aidl_appData = toAidlView(applicationData);

    struct kmhal_arg_write_desc in_args[] = {
        init_write_i("keyBlob", &aidl_keyBlob, write_aidl_vec_of_u8),
        init_write_i("appId", &aidl_appId, write_aidl_vec_of_u8),
        init_write_i("appData", &aidl_appData, write_aidl_vec_of_u8),
    };
    const size_t n_in_args = u_arr_size(in_args);

    struct aidl_vec_of_key_characteristics res_kc_vec{};
    struct kmhal_arg_parse_desc out_args[] = {
        init_parse_i("KeyCharacteristics[]", &res_kc_vec, parse_aidl_vec_of_key_characteristics)
    };
    const size_t n_out_args = u_arr_size(out_args);

    if (kmhal_call(this->hal_.get(), 14,
                in_args, n_in_args, out_args, n_out_args))
    {
        std::cerr << __func__ << ": AIDL call failed" << std::endl;
        destroy_aidl_vec_of_key_characteristics(&res_kc_vec);
        return ErrorCode::SECURE_HW_COMMUNICATION_FAILED;
    }

    convertAndDestroyKeyCharacteristics(out_keyCharacteristics, res_kc_vec);
    return ErrorCode::OK;
}

ErrorCode SusAidlKeyMint::exportKey(KeyFormat keyFormat, std::vector<u8> const& keyBlob,
        std::vector<u8> const& applicationId, std::vector<u8> const& applicationData,
        std::vector<u8>& out_keyMaterial)
{
    (void) keyFormat; (void) keyBlob; (void) applicationId; (void) applicationData;
    (void) out_keyMaterial;
    return ErrorCode::UNIMPLEMENTED;
}

ErrorCode SusAidlKeyMint::attestKey(std::vector<u8> const& keyToAttest,
        std::vector<KeyParameter> const& attestParams,
        std::vector<std::vector<u8>>& out_certChain)
{
    (void) keyToAttest; (void) attestParams; (void) out_certChain;
    return ErrorCode::UNIMPLEMENTED;
}

ErrorCode SusAidlKeyMint::upgradeKey(std::vector<u8> const& keyBlobToUpgrade,
        std::vector<KeyParameter> const& upgradeParams, std::vector<u8>& out_upgradedKeyBlob)
{
    (void) keyBlobToUpgrade; (void) upgradeParams; (void) out_upgradedKeyBlob;
    return ErrorCode::UNIMPLEMENTED;
}

ErrorCode SusAidlKeyMint::deleteKey(std::vector<u8> const& keyBlob) {
    (void) keyBlob; return ErrorCode::UNIMPLEMENTED;
}

ErrorCode SusAidlKeyMint::deleteAllKeys(void) { return ErrorCode::UNIMPLEMENTED; }

ErrorCode SusAidlKeyMint::destroyAttestationIds(void) { return ErrorCode::UNIMPLEMENTED; }

ErrorCode SusAidlKeyMint::begin(KeyPurpose purpose, std::vector<u8> const& keyBlob,
        std::vector<KeyParameter> const& inParams, HardwareAuthToken const& authToken,
        std::vector<KeyParameter>& out_outParams, uint64_t& out_operationHandle)
{
    (void) purpose; (void) keyBlob; (void) inParams; (void) authToken;
    (void) out_outParams; (void) out_operationHandle;
    return ErrorCode::UNIMPLEMENTED;
}

ErrorCode SusAidlKeyMint::update(uint64_t operationHandle,
        std::vector<KeyParameter> const& inParams, std::vector<u8> const& input,
        HardwareAuthToken const& authToken,
        uint32_t& out_inputConsumed, std::vector<KeyParameter>& out_outParams,
        std::vector<u8>& out_output)
{
    (void) operationHandle; (void) inParams; (void) input;
    (void) authToken;
    (void) out_inputConsumed; (void) out_outParams; (void) out_output;
    return ErrorCode::UNIMPLEMENTED;
}

ErrorCode SusAidlKeyMint::finish(uint64_t operationHandle,
        std::vector<KeyParameter> const& inParams, std::vector<u8> const& input,
        std::vector<u8> const& signature, HardwareAuthToken const& authToken,
        std::vector<KeyParameter>& out_outParams, std::vector<u8>& out_output)
{
    (void) operationHandle; (void) inParams; (void) input; (void) signature;
    (void) authToken;
    (void) out_outParams; (void) out_output;
    return ErrorCode::UNIMPLEMENTED;
}

ErrorCode SusAidlKeyMint::abort(uint64_t operationHandle) {
    (void) operationHandle; return ErrorCode::UNIMPLEMENTED;
}

static void convertAndDestroyKeyCharacteristics(KeyCharacteristics& out,
                                struct aidl_vec_of_key_characteristics &res_kc_vec)
{
    for (i32 i = 0; i < res_kc_vec.size; i++) {
        struct aidl_key_characteristics *const kc = &res_kc_vec.ptr[i];

        switch (kc->slvl) {
        default:
            std::cerr << "KeyMint: WARNING: Unknown securityLevel: " << kc->slvl
                << "; treating SECURITY_LEVEL_SOFTWARE" << std::endl;
        case KM_SECURITY_LEVEL_SOFTWARE:
        case KM_SECURITY_LEVEL_KEYSTORE:
            for (i32 i = 0; i < kc->authorizations.size; i++)
                out.softwareEnforced.emplace_back(fromAidl(kc->authorizations.ptr[i]));
            break;
        case KM_SECURITY_LEVEL_TRUSTED_ENVIRONMENT:
        case KM_SECURITY_LEVEL_STRONGBOX:
            for (i32 i = 0; i < kc->authorizations.size; i++)
                out.hardwareEnforced.emplace_back(fromAidl(kc->authorizations.ptr[i]));
            break;
        }
    }

    destroy_aidl_vec_of_key_characteristics(&res_kc_vec);
}

} /* namespace kmhal */
} /* namespace suskeymaster */

#else
namespace suskeymaster {
namespace kmhal {
SusAidlKeyMint() {
}
} /* namespace kmhal */
} /* namespace suskeymaster */
#endif /* SUSKEYMASTER_BUILD_HOST */

#endif /* SUSKEYMASTER_HAL_DISABLE_KEYMINT */
